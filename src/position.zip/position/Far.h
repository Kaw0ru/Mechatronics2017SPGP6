int Far(int* scanResult, int* scanResultHist, int* DesiredLoc, int* k, int* angle)
{
	bool FWD = 0;
	int angX = 0;
	int angY = 0;
	int errorX = *(DesiredLoc) - *(scanResult);
	int errorY = *(++DesiredLoc) - *(++scanResultHist);
	
	if (*(scanResult++)==*(scanResultHist++)) // to check how many times y keeps immutable
	{
		(*k) ++ ;
	} 
	else
	{
		*k = 0;
	}

	// Determin angX
	if (*k>10) // the ball is out of the view
  {
    if (errorX > 0)
    {
    	FWD = 0;
    	angX = 30; //Turn left
    }
    else
    {
    	FWD = 0;
    	angX = -30; //Turn right
    }
  }
  else
  {
  	if (abs(errorX)>=10) //to avoid the tiny disturbance
  	{
    	if (errorX>0)
    	{
      	FWD = 0;// turn left
      	angX = -1;
    	}
    	else
    	{
      	FWD = 0;//turn right
      	angX = 1;
    	} 
  	}
  	else
  	{
  		FWD = 1; //go straight
  		angX = 0;
  	}
  }
  
  if (abs(errorY)>=8) //to avoid the tiny disturbance
  {
    ang = *angle;
    double Dec = 100;
    double delta = double(errorY) / Dec;
    delta = 9*atan(delta)/3.14; // delta angle
    ang = ang + delta*100;
	}

	int result[4] = {FWD, angX, angY, k, ang};



	return result; //angle = 100 * angle as a int.
}